<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Auth;
use App\Models\{
    Invoice, InvoiceProduct, PackingslipNew1, Packingslip,
    Ledger, Bill, WhatsAppInvoice
};

class InvoiceApiController extends Controller
{
      public function deliverNow(Request $request, $packingslip_id)
    {
        
        DB::beginTransaction();

        try {

            // 🔐 Prevent duplicate invoice
            $packingSlip = PackingslipNew1::findOrFail($packingslip_id);

            if ($packingSlip->invoice_id) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invoice already generated for this packing slip'
                ], 400);
            }

            $params = $request->all();
            dd($params);
            // 🧾 Generate Invoice Number
            $invoice_no = genAutoIncreNoInv();
            $net_price  = $params['net_price'];

            // 1️⃣ Insert Invoice
            $invoiceId = Invoice::insertGetId([
                'packingslip_id' => $packingslip_id,
                'invoice_no' => $invoice_no,
                'net_price' => $net_price,
                'required_payment_amount' => $net_price,
                'order_id' => $params['order_id'],
                'store_id' => $params['store_id'],
                'user_id' => $params['user_id'],
                'is_gst' => $params['is_gst'],
                'store_address_outstation' => $params['store_address_outstation'],
                'created_at' => now(),
                'updated_at' => now(),
                'created_by' => auth()->id() ?? $params['user_id']
            ]);

            // 2️⃣ WhatsApp Invoice Entry
            WhatsAppInvoice::create([
                'packingslip_id' => $packingslip_id,
                'invoice_id' => $invoiceId,
                'invoice_no' => $invoice_no,
                'net_price' => $net_price,
                'required_payment_amount' => $net_price,
                'order_id' => $params['order_id'],
                'store_id' => $params['store_id'],
                'user_id' => $params['user_id'],
                'is_gst' => $params['is_gst'],
                'store_address_outstation' => $params['store_address_outstation'],
                'created_at' => now(),
                'updated_at' => now(),
                'created_by' => auth()->id() ?? $params['user_id']
            ]);

            // 3️⃣ Invoice Products
            foreach ($params['details'] as $item) {
                InvoiceProduct::create([
                    'invoice_id' => $invoiceId,
                    'product_id' => $item['product_id'],
                    'product_name' => $item['product_name'],
                    'quantity' => $item['quantity'],
                    'pcs' => $item['pcs'],
                    'price' => $item['price'],
                    'single_product_price' => $item['single_product_price'],
                    'count_price' => $item['count_price'],
                    'total_price' => $item['total_price'],
                    'is_store_address_outstation' => $item['is_store_address_outstation'],
                    'hsn_code' => $item['hsn_code'],
                    'igst' => $item['igst'],
                    'cgst' => $item['cgst'],
                    'sgst' => $item['sgst'],
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            }

            // 4️⃣ Bill Entry
            DB::table('bills')->insert([
                'store_id' => $params['store_id'],
                'invoice_id' => $invoiceId,
                'transaction_id' => $invoice_no,
                'entry_date' => now()->toDateString(),
                'amount' => $net_price,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // 5️⃣ Update Packing Slip ✅
            $packingSlip->update([
                'invoice_id' => $invoiceId,
                'status' => 'Delivered'
            ]);

            // 6️⃣ Ledger Entry
            Ledger::create([
                'user_type' => 'store',
                'store_id' => $params['store_id'],
                'transaction_id' => $invoice_no,
                'transaction_amount' => $net_price,
                'is_debit' => 1,
                'bank_cash' => $params['is_gst'] ? 'bank' : 'cash',
                'is_gst' => $params['is_gst'],
                'entry_date' => now()->toDateString(),
                'purpose' => 'invoice',
                'purpose_description' => 'invoice raised of sales order for store',
                'created_at' => now(),
                'updated_at' => now()
            ]);

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Invoice generated & delivered successfully',
                'invoice_id' => $invoiceId,
                'invoice_no' => $invoice_no,
                'net_amount' => $net_price
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

}
